export const getTotal = (store) => {
  const { list, checkout } = store;
  const totalCount = Object.values(checkout).reduce((acc, cur) => acc + cur, 0);
  const totalPrice = Object.entries(checkout)
    .reduce((acc, cur) => {
      const item = list.find(({ sku }) => sku === Number(cur[0]));
      return acc + cur[1] * item.price;
    }, 0)
    .toFixed(2);
  return { totalCount, totalPrice };
};
